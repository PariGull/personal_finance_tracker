"""
Forecasting module for Personal Finance Tracker.
Provides time-series forecasting algorithms:
1. Simple Moving Average (SMA)
2. Linear Regression (Ordinary Least Squares - OLS)
3. Holt-Winters Triple Exponential Smoothing
4. ARIMA (AutoRegressive Integrated Moving Average)
"""

import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error
try:
    from statsmodels.tsa.arima.model import ARIMA
    from statsmodels.tsa.holtwinters import ExponentialSmoothing
except ImportError:
    ARIMA = None
    ExponentialSmoothing = None

def evaluate_and_compare_models(series: pd.Series, horizon: int = 3, holdout_size: int = 3):
    total_len = len(series)
    actual_holdout = max(1, min(holdout_size, int(total_len * 0.3)))
    train_split = series.iloc[:-actual_holdout]
    test_split = series.iloc[-actual_holdout:]
    # Computes MAE, RMSE and returns ranked model tournament
