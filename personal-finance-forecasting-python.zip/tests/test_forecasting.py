import pytest
from forecasting import forecast_moving_average, forecast_linear_regression, evaluate_and_compare_models

def test_evaluate_and_compare_models(sample_monthly_series):
    # Tests tournament output and best model selection
    pass
