"""
Personal Finance Tracker with Forecasting & Statistical Insights
Portfolio Project built with Streamlit, SQLite, pandas, statsmodels, scikit-learn, and Plotly.
"""

from datetime import date, datetime
import io
import os
import sqlite3
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from db import (
    DEFAULT_DB_PATH,
    add_category,
    add_transaction,
    delete_transaction,
    get_budget_vs_actual,
    get_categories,
    get_connection,
    get_monthly_spending_series,
    get_transactions_df,
    init_db,
    set_budget,
    update_transaction,
)
from forecasting import (
    MATH_EXPLANATIONS,
    evaluate_and_compare_models,
    prepare_monthly_series,
)
from generate_data import generate_sample_data
from utils import (
    detect_outliers_iqr,
    detect_outliers_zscore,
    export_transactions_to_csv,
    generate_plain_english_summary,
    parse_csv_transactions,
)

st.set_page_config(
    page_title="Personal Finance Tracker & Forecasting",
    page_icon="📈",
    layout="wide",
    initial_sidebar_state="expanded",
)

init_db(DEFAULT_DB_PATH)

st.sidebar.title("💰 Finance Tracker")
st.sidebar.caption("Portfolio Project | BS Mathematics Edition")

nav_page = st.sidebar.radio(
    "Navigation",
    [
        "📊 Dashboard & Trends",
        "💳 Transactions Ledger",
        "🎯 Budgets & Alerts",
        "🔮 Time-Series Forecasting",
        "🔍 Outlier & Anomaly Insights",
        "📐 Mathematical Foundations",
    ],
)

if st.sidebar.button("🎲 Generate 18-Mo Sample Data", use_container_width=True):
    with st.spinner("Populating 18 months of realistic transactional data..."):
        generate_sample_data(months_back=18, db_path=DEFAULT_DB_PATH)
        st.sidebar.success("Database populated with 18 months of history!")
        st.rerun()
# (See full file in repository)
