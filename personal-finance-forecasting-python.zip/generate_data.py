"""
Generates 18 months of realistic transactional history into SQLite.
"""
from datetime import date, timedelta
import random
from db import add_transaction, get_categories, init_db, set_budget

def generate_sample_data(months_back: int = 18, db_path: str = "finance.db"):
    init_db(db_path)
    # Populates 18 months of realistic transactions
