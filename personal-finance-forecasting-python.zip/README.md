# 📈 Personal Finance Tracker with Time-Series Forecasting
A portfolio project for BS Mathematics graduates combining SQLite, Streamlit, and stochastic time-series models.
